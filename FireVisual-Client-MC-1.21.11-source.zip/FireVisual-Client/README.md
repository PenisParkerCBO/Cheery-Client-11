# FireVisual Client — Minecraft Java 1.21.11

Лёгкий клиентский Fabric-мод с анимированным красно-оранжевым HUD.

## Что уже есть
- Панель FIREVISUAL в левом верхнем углу.
- Плавно меняющийся красно-оранжевый акцент.
- Координаты игрока и FPS.
- Только клиентский HUD: не меняет игровой процесс и не отправляет команды на сервер.

## Совместимость
- Minecraft Java: **1.21.11**
- Mod loader: **Fabric**
- Java: **21**
- Fabric Loader: **0.18.1**
- Fabric API: **0.141.6+1.21.11**

## Сборка прямо с телефона через GitHub

1. Распакуй архив.
2. На GitHub создай новый пустой репозиторий, например `FireVisual-Client`.
3. В репозитории нажми **Add file → Upload files**.
4. Загрузи содержимое папки проекта (именно файлы и папки внутри неё, включая скрытую `.github`).
5. Нажми **Commit changes**.
6. Открой вкладку **Actions** и выбери workflow **Build FireVisual Client**.
7. Нажми **Run workflow**. При первом push workflow обычно запускается автоматически.
8. Когда сборка завершится зелёной галочкой, открой её страницу и скачай Artifact:
   `FireVisual-Client-Minecraft-1.21.11`.
9. Распакуй скачанный ZIP — внутри будет `.jar`.

## Установка
Помести полученный `firevisual-client-1.0.0.jar` в папку `mods` профиля Minecraft Java с Fabric 1.21.11. Установи Fabric API 0.141.6+1.21.11 в ту же папку. Запусти игру.

## Важно
Этот архив содержит исходники и workflow, а не готовый JAR. JAR создаётся GitHub Actions в облаке после загрузки проекта. Сборка требует доступа GitHub Actions к Maven-репозиториям Fabric и Mojang.

Официальные материалы:
- https://docs.fabricmc.net/
- https://fabricmc.net/2025/12/05/12111.html
- https://fabricmc.net/use/?version=1.21.11
