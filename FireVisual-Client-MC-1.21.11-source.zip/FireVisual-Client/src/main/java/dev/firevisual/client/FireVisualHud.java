package dev.firevisual.client;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

public final class FireVisualHud {
    private static final int PANEL = 0xB91A1020;
    private static final int PANEL_EDGE = 0xFFFF3B45;
    private static final int WHITE = 0xFFF8F4FF;
    private static final int MUTED = 0xFFB9AFC5;
    private static final Identifier LOGO = Identifier.fromNamespaceAndPath("firevisual", "logo");

    private FireVisualHud() {}

    public static void render(GuiGraphics graphics, DeltaTracker tickCounter) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.options.hideGui || mc.player == null || mc.level == null) return;

        LocalPlayer player = mc.player;
        long now = System.currentTimeMillis();
        float pulse = (float) (0.5 + 0.5 * Math.sin(now / 420.0));
        int accent = blend(0xFFFF334D, 0xFFFFA52E, pulse);

        int x = 10;
        int y = 10;
        int width = 142;
        int height = 54;

        graphics.fill(x + 2, y + 2, x + width + 2, y + height + 2, 0x55000000);
        graphics.fill(x, y, x + width, y + height, PANEL);
        graphics.fill(x, y, x + width, y + 2, accent);
        graphics.fill(x, y + 2, x + 2, y + height, PANEL_EDGE);

        graphics.drawString(mc.font, Component.literal("FIREVISUAL"), x + 9, y + 7, WHITE, false);
        graphics.drawString(mc.font, Component.literal("CLIENT  •  1.21.11"), x + 9, y + 19, MUTED, false);

        String coords = String.format("XYZ  %d  %d  %d",
            player.getBlockX(), player.getBlockY(), player.getBlockZ());
        graphics.drawString(mc.font, Component.literal(coords), x + 9, y + 34, accent, false);

        String fps = mc.getFps() + " FPS";
        int fpsWidth = mc.font.width(fps);
        graphics.drawString(mc.font, Component.literal(fps),
            x + width - fpsWidth - 8, y + 7, accent, false);
    }

    private static int blend(int a, int b, float t) {
        int aa = (a >>> 24) & 255, ar = (a >>> 16) & 255, ag = (a >>> 8) & 255, ab = a & 255;
        int ba = (b >>> 24) & 255, br = (b >>> 16) & 255, bg = (b >>> 8) & 255, bb = b & 255;
        int ca = (int) (aa + (ba - aa) * t);
        int cr = (int) (ar + (br - ar) * t);
        int cg = (int) (ag + (bg - ag) * t);
        int cb = (int) (ab + (bb - ab) * t);
        return (ca << 24) | (cr << 16) | (cg << 8) | cb;
    }
}
